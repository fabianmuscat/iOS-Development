//
//  Person.swift
//  L3_StackViews
//
//  Created by Fabian Muscat on 15/05/2021.
//

import Foundation

class Person : AppDelegate {
    private var _name: String
    private var _age: Int
    
    var Name: String {
        get { _name }
        set { _name = newValue }
    }
    
    var Age: Int {
        get { _age }
        set { _age = newValue }
    }
    
    init(name: String, age: Int) {
        _name = name
        _age = age
    }
    
    override
    
}
