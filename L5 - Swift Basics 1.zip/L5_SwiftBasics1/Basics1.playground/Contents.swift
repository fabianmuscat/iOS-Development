import UIKit

var str = "Hello, playground"
print(str)

str = "some data"
print(str)

let con = "more data"
// con = "modified data" => Cannot assign to value: 'con' is a 'let' constant

var b = true
print(b)

var i = 32
i = 0
i = -10
// i = 0.345 => Cannot assign value of type 'Double' to type 'Int'

var f = 0.3493 // Double by default
