//
//  ViewController.swift
//  Sample
//
//  Created by Fabian Muscat on 15/05/2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}

